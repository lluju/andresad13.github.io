
[andresad13 blog, take a look](http://andresad13.github.io)
